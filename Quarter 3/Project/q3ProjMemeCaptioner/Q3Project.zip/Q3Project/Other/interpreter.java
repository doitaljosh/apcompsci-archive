public class interpreter {

   public String greeting() {
      return "Type in an emotion such as "happy" or "sad" ";
   }
   
   public String defaultResponse() {
      return { "Hello, fellow human! My name is Reuben! " 
      "Please enter a response so I may converse with you ", 
      "as is common among homosapiens, which I definitely am! " 
      "I am not a robot! That is a very silly thing for you to think!";
      }
   }

   public static void main(String[] args) {
      
      
      
   }
      
}