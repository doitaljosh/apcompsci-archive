package net.TeSqGr.APCSQ3Project;

public interface Constants {

     int MOOD_NEEDED = 3;
}
