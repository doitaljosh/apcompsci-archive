package net.TeSqGr.APCSQ3Project;

import java.util.Scanner;

public class MemeGenerator {

    static Scanner s = new Scanner(System.in);

    public static void main(String[] args){
        while(true){
            System.out.println(s.next());
        }
    }
}
