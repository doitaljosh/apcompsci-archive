package net.TeSqGr.APCSQ3Project.handler;

public class MoodHandler extends Handler {

    public MoodHandler(){

        sw
    }

    @Override
    public void loop() {

    }
}
