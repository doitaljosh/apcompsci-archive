package net.TeSqGr.APCSQ3Project.handler;

public abstract class Handler {

    private int handlerID = -1;

    public Handler(String name, int id){

    }

    private String handlerName = "Handler";

    public int getHandlerID() {
        return handlerID;
    }

    public String getHandlerName() {
        return handlerName;
    }

    public void setHandlerID(int handlerID) {
        this.handlerID = handlerID;
    }

    public abstract void loop();

    @Override
    public String toString() {
        return getHandlerName() + " : " + getHandlerID();
    }
}
