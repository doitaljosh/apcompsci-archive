/*
   Luke Judy
   Period 2-5
   10/31/2017
*/

import java.util.*;
import java.util.Random;

public class LukeJudyDungeonClass
{
   // defines an array of rooms
   static String[] roomArray = {"Empty Room","Loot Room","Trap Room (Empty)","Trap Room (Loot)","Enemy Room"};
   static List<String> arrayList = new ArrayList<String>();
   
   // main
   public static void dungeonClass()
   {   
      // Starting Room text
      System.out.println("You suddenly find yourself in a dimly lit room that appears to have nothing in it.");
      System.out.println("'I thought I just walked into my master bathroom...' you say to yourself.");
      System.out.println("You really have to go to the bathroom.");
      System.out.println("You look behind you to leave this strange room, but the door you walked through has disappeared.");
      System.out.println("In front of you, however, is a new door. Proceed?");
      /*player input*/
      
      // creates a pause before choosing a random room
      try
      {
         Thread.sleep(5000);
      }
      catch(InterruptedException e){}
   
      for(String s: roomArray)
         arrayList.add(s);
      // chooses a room at random from the roomArray
      Random random = new Random();
      String chosenString = arrayList.get(random.nextInt(arrayList.toArray().length));
      System.out.println("!!! " + chosenString + " !!!");
   
      // describes what happens when an empty room is chosen 
      if (chosenString == "Empty Room")
      {
         System.out.println("You enter a dimly lit room that appears to have nothing in it. On the other side of the room is a door.");
         System.out.println("What do you do?");
      /*player input*/
      }
      
      // describes what happens when a loot room is chosen
      else if (chosenString == "Loot Room")
      {
         System.out.println("You enter a very well-lit room that has a small wooden chest in the middle of it. On the other side of the room is a door.");
         System.out.println("What do you do?");
      /*player input*/
      }
      
      // describes what happens when a trapped empty room is chosen
      else if (chosenString == "Trap Room (Empty)")
      {
         System.out.println("You enter a dimly lit room that appears to have nothing in it. On the other side of the room is a door.");
         System.out.println("What do you do?");
      /*player input*/
      }
      
      // describes what happens when a trapped loot room is chosen
      else if (chosenString == "Trap Room (Loot)")
      {
         System.out.println("You enter a very well-lit room that has a small wooden chest in the middle of it. On the other side of the room is a door.");
         System.out.println("What do you do?");
      /*player input*/
      }
      
      // describes what happens when an enemy room is chosen
      else if (chosenString == "Enemy Room")
      {
         System.out.println("You enter a room that is entirely blood-red from floor to ceiling. Standing in front of you is a creature that looks like a small version of an orc from the Lord of the Rings.");
         System.out.println("However, this particular monster is holding a" /*+ weapon*/ + ".");
         System.out.println("What do you do?");
      /*player input*/
      }
   
   }
   
}