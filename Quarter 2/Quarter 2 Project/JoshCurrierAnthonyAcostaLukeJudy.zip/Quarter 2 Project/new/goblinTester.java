public class goblinTester {

   public static void main(String[] args) {
      
      goblinClass goblin = new goblinClass();
      goblin.startThreads();
   
   }

}