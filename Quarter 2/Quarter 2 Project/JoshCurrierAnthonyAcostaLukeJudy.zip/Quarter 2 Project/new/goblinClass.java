/*Josh Currier
Quarter 2 Project
Goblin Class; APCS*/

import java.util.*;
import java.lang.*;

public class goblinClass {

   public int i; //Loop variable
   public int width; //Playfield width
   public int height; //Playfirld height
   public int playField; //Playfield area
   public int damage; //Declare damage variable
   public int maxDamage = 500; //Maximum damage level
   public int numPlayers = 1; //Maximum number of players
   public int chosenWeapon; //Set default weapon
   public int action; //Declare action variable
   public int goblinHealth = 10000; //Maximum health level
   public int minHealth = 0; //Minimum health threshold
   public double playerHealth = 10000.0; //Maximum player health level
   public boolean clearedPos; //Cleared position boolean
   public int availPos = playField; //Declare the maximum available positions to equal the area of the playfield
   
   //I know you're triggered by this, but it's not what you think.
   Thread loot = new Thread(new Runnable() {
   
      public void run() {
         //define array of available weapons
         int[] lootArray = {100, 50, 150, 300, 350, 250, 500, 0};
         //Set and define the dungeon size
         width = 8;
         height = 8;
         playField = width * height;
         //Randomly choose weapon until all of the play area is discovered
         for(i = 1; i <= playField; i++) {
            chosenWeapon = (lootArray[new Random().nextInt(lootArray.length)]);
               //Sets damage level of weapon based on what weapon is selected.
               if(chosenWeapon == lootArray[0]) {   
                  damage = chosenWeapon;
                  System.out.println("Goblin has not found any new weapons. Damage remains 100.");
               } else if (chosenWeapon == lootArray[1]) {   
                  damage = chosenWeapon;
                  System.out.println("Goblin has found a Knife. Damage is now: " + damage);
               } else if (chosenWeapon == lootArray[2]) {  
                  damage = chosenWeapon;
                  System.out.println("Goblin has found a Hammer. Damage is now: " + damage);
               } else if (chosenWeapon == lootArray[3]) {     
                  damage = chosenWeapon;
                  System.out.println("Goblin has found a Shovel. Damage is now: " + damage);
               } else if (chosenWeapon == lootArray[4]) { 
                  damage = chosenWeapon;
                  System.out.println("Goblin has found a Jerry can. Damage is now: " + damage);
               } else if (chosenWeapon == lootArray[5]) {
                  damage = chosenWeapon;
                  System.out.println("Goblin has found a Katana. Damage is now: " + damage);
               } else if (chosenWeapon == lootArray[6]) {
                  damage = chosenWeapon;
                  System.out.println("Goblin has found a Rocket Launcher. Damage is now: " + damage);
                  numPlayers = numPlayers--;
               } else {
                  System.out.println("Goblin has not found any new weapons.");
               }
            //Catch exceptions. Why? Because Java.       
            try {
            Thread.sleep(1000);
            } catch(InterruptedException e) {
            }           
         }
      }
   });
   
   Thread goblinAction = new Thread(new Runnable() {
   
      public void run() {
         //define array of goblin actions
         int[] goblin = {0, chosenWeapon, 1, 2, 3};
         
        
         //Randomly choose what the goblin will do within position size
         for(i = 1; i <= playField; i++) {
            action = (goblin[new Random().nextInt(goblin.length)]);
            //Attack player
            if (playerHealth <= 0.0) {
               numPlayers--;
               System.out.println("The player has died!");
            }
            if (numPlayers <= 0) {
              System.out.println("All players have been destroyed");
              System.exit(1);
            }
            if (action == goblin[1]) {
               playerHealth = playerHealth - chosenWeapon;
               System.out.println("Goblin has attacked a player! That player's health is now: " + playerHealth);
            } else {
               switch (action) {
                  //Restore health
                  case 0:
  
                     System.out.println("Goblin has restored health.");
                     goblinHealth = 10000;
                  break;
                  //Clear a position
                  case 1:
                  //   System.out.println("Goblin has cleared a position.");
                  //  clearedPos = true;
                  //   availPos = availPos--;
                  break;
                  //Player attacks goblin
                  case 2:
                     System.out.println("Goblin has been attacked.");
                     goblinHealth = goblinHealth - chosenWeapon;  
                  break;
                  case 3:
                     System.out.println("Player has restored health.");
                     playerHealth = 10000;
                  break;
                  //This should never run, except in the case of a solar flare or an EMP WMD.
                  default:
                     System.out.println("Something seriously bad has happened! Go get some cover!");
                     System.out.println("Goblin.exe has stopped responding.");
                  } 
            }  
            //Stop running if goblin has reached minimum health threshold
            if (goblinHealth <= minHealth) {
               System.out.println("Goblin has died!");
               System.exit(1);
            }
            if (playerHealth > goblinHealth) {
               System.out.println("Player is in the lead.");
            } else if (goblinHealth > playerHealth) {
               System.out.println("Enemy is in the lead.");
            }
            
            
            //Stop running if all positions have been cleared
            //if (availPos == 0) {
            //   System.out.println("All positions have been cleared. Stop.");
            //   System.exit(1);
            //}
            //Catch exceptions. Why? Because Java.
            try {
            Thread.sleep(1000);
            } catch(InterruptedException e) {
            }
         }
      }
   });
   
   public void startThreads() {
      loot.start();
      goblinAction.start();
   }
   
}