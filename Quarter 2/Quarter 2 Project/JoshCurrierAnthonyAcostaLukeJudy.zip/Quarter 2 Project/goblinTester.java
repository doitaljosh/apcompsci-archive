public class goblinTester {

   public static void main(String[] args) {
      
      currierGoblinClass goblin = new currierGoblinClass();
      goblin.startThreads();
      
      Thread HeroAcosta = new Thread(new Runnable() {
         public void run() {
            HeroAcosta anthonyA = new HeroAcosta();
            anthonyA.acostaPlayerClass();
         }
      });
      try {
      Thread.sleep(1000);
      } catch(InterruptedException e) {
      }
      
      Thread LukeJudyDungeonClass = new Thread(new Runnable() {
         public void run() {
            LukeJudyDungeonClass lukeJ = new LukeJudyDungeonClass();
            lukeJ.dungeonClass();
         }
      });
      try {
      Thread.sleep(1000);
      } catch(InterruptedException e) {
      }
   }
}