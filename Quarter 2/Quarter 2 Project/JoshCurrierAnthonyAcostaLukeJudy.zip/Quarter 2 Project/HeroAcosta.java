/* Anthony R. Acosta
   2-1       11-6-17
*/

public class HeroAcosta {

public static void acostaPlayerClass() {

   String playerName = "ray";
   
      int[] aarray;

         aarray = new int[5];

         aarray[0] = 5;

         aarray[1] = 10;
   
         aarray[2] = 15;

         aarray[3] = 25;

         aarray[4] = 50;
      
      //number of enemys killed                           
      int kills = 0;
      
      //the more enemys killed the better the weapon the player will use
      while (kills < 10){
      System.out.println(playerName + " attacked with his fist doing " + aarray[0] + " damage");
      kills++;
      }     
      
      while (kills < 20){
      System.out.println(playerName + " attacked with his knife doing " + aarray[1] + " damage");
      kills++;
      }                       
      
      while (kills < 24){
      System.out.println(playerName + " attacked with his rusty sword doing " + aarray[2] + " damage");
      kills++;
      }
      
      while (kills < 26){
      System.out.println(playerName + " attacked with his broad sword doing " + aarray[3] + " damage");
      kills++;
      }
      
      while (kills < 27){
      System.out.println(playerName + " attacked with his heros sword doing " + aarray[4] + " damage");
      kills++;
      }
      
      
      //stats
      int playerHP = 0; 
      //inventory 
      int jerrycan = 100;
      int flamethrower = 125;
      int shotgun = 50;
      int potion = 0;
      int heal = 1000;
      
      //using inventory
      if(playerHP <= 1000){
      System.out.println(playerName + " used potion to heal");
      playerHP = heal + playerHP;
      potion--;
      System.out.println(playerName + " now has: " + playerHP);
      }
      
      //collection 
      System.out.println(playerHP +"HP");
      System.out.println(jerrycan + " # of jerrycans unused");
      System.out.println(flamethrower +" # of flamethrower unused");
      System.out.println(shotgun +" # of shotgun unused");
      System.out.println(potion + " # of potions");
            
      //if the player has no potions and reachs o hp he loses
      int retryCount = 0;
      
      if (potion == -1){
      System.out.println(playerName + " has been defeated");
      retryCount++;
      playerHP = 5000;
      }
               

   }//main

}//public class